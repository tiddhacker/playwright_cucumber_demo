package com.automation.common;

import com.automation.pages.*;
import com.automation.pages.HR_InterviewGuide.*;
import com.automation.pages.HR_Onboarding.*;
import com.automation.pages.HR_ProductTraining.*;
import com.automation.pages.NCCPlanBot.*;
import com.automation.pages.NCCTrainingAssist.*;
import com.automation.pages.NCCTrainingBot.*;
import com.automation.utils.*;
import com.microsoft.playwright.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import java.nio.file.*;
import java.util.Arrays;

public class Mappings {
	// for parallel execution
	private static ThreadLocal<Playwright> tlPlaywright = new ThreadLocal<>();
	private static ThreadLocal<Browser> tlBrowsers = new ThreadLocal<>();
	private static ThreadLocal<BrowserContext> tlBrowserContext = new ThreadLocal<>();
	private static ThreadLocal<Page> tlPage = new ThreadLocal<>();
	private static ThreadLocal<Path> tlUserDataDir = new ThreadLocal<>();

	// utilities references
	private static Logger log;
	public static FileUtils fileutils;
	public static BasePage basepage;
	public static CommonUtils commonUtils;
	public static Xls_Reader xlsReadr;
	public static DataStorage dataStorage;
	public static CustomAssert customAssert;
	public static JsonUtils jsonUtils;
	public static ApiHelper apiHelper;
	public static TokenUtils tokenUtils;

	// all page references here
	public static HROnboardingLoginPage hrOnboardingLoginPage;
	public static HROnboardingDashboardPage hrOnboardingDashboardPage;
	public static InterviewGuideDashboardPage interviewGuideDashboardPage;
	public static InterviewGuideLoginPage interviewGuideLoginPage;
	public static TIAAServiceNowPage tiaaServiceNowPage;
	public static NCCTrainingBotLoginPage nccTrainingBotLoginPage;
	public static NCCTrainingBotDashboardPage nccTrainingBotDashboardPage;
	public static NCCPlanBotLoginPage nccPlanBotLoginPage;
	public static NCCPlanBotDashboardPage nccPlanBotDashboardPage;
	public static HRProductTrainingLoginPage hrProductTrainingLoginPage;
	public static HRProductTrainingDashboardPage hrProductTrainingDashboardPage;
	public static TrainingAssistLoginPage trainingAssistLoginPage;
	public static TrainingAssistDashboardPage trainingAssistDashboardPage;

	public void initBrowser() {
		String browserName = System.getProperty("browser", "chrome").trim();
		boolean headlessVal = Boolean.parseBoolean(System.getProperty("headless", "false").trim());
		boolean isIncognitoMode = Boolean.parseBoolean(System.getProperty("incognitoMode", "false").trim());

		tlPlaywright.set(Playwright.create());

		try {
			if (isIncognitoMode) {
				Path userDataDir = Files.createTempDirectory("pw-user-data-" + Thread.currentThread().getId());
				tlUserDataDir.set(userDataDir);

				BrowserContext context = getPlaywright().chromium().launchPersistentContext(
						userDataDir,
						new BrowserType.LaunchPersistentContextOptions()
								.setHeadless(headlessVal)
								.setArgs(Arrays.asList(
										"--incognito",
										"--disable-extensions",
										"--disable-blink-features=BlockCredentialedSubresources",
										"--auth-server-whitelist=",
										"--auth-negotiate-delegate-whitelist="
								))
				);
				tlBrowserContext.set(context);
				tlPage.set(context.pages().get(0));
			} else {
				switch (browserName.toLowerCase()) {
					case "chromium":
						tlBrowsers.set(getPlaywright().chromium().launch(new BrowserType.LaunchOptions().setHeadless(headlessVal)));
						break;
					case "firefox":
						tlBrowsers.set(getPlaywright().firefox().launch(new BrowserType.LaunchOptions().setHeadless(headlessVal)));
						break;
					case "safari":
						tlBrowsers.set(getPlaywright().webkit().launch(new BrowserType.LaunchOptions().setHeadless(headlessVal)));
						break;
					case "chrome":
						tlBrowsers.set(getPlaywright().chromium().launch(new BrowserType.LaunchOptions().setHeadless(headlessVal)));
						break;
					case "edge":
						tlBrowsers.set(getPlaywright().webkit().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(headlessVal)));
						break;
					default:
						log.info("Please Pass Correct Browser Name");
						break;
				}
				tlBrowserContext.set(getBrowser().newContext());
				tlPage.set(getBrowserContext().newPage());
			}
		} catch (Exception e) {
			throw new RuntimeException("Failed to initialize browser", e);
		}
	}

	public static Playwright getPlaywright() {
		return tlPlaywright.get();
	}

	public static Browser getBrowser() {
		return tlBrowsers.get();
	}

	public static BrowserContext getBrowserContext() {
		return tlBrowserContext.get();
	}

	public static Page getPage() {
		Page page = tlPage.get();
		if (page != null) {
			page.onDownload(download -> {
				String path = download.suggestedFilename();
				download.saveAs(Paths.get("target/" + path));
			});
		}
		return page;
	}

	public void initUIClass() {
		basepage = new BasePage();
		hrOnboardingLoginPage = new HROnboardingLoginPage(getPage());
		hrOnboardingDashboardPage = new HROnboardingDashboardPage(getPage());
		tiaaServiceNowPage = new TIAAServiceNowPage(getPage());
		interviewGuideDashboardPage = new InterviewGuideDashboardPage(getPage());
		interviewGuideLoginPage = new InterviewGuideLoginPage(getPage());
		nccTrainingBotLoginPage = new NCCTrainingBotLoginPage(getPage());
		nccTrainingBotDashboardPage = new NCCTrainingBotDashboardPage(getPage());
		nccPlanBotLoginPage = new NCCPlanBotLoginPage(getPage());
		nccPlanBotDashboardPage = new NCCPlanBotDashboardPage(getPage());
		hrProductTrainingLoginPage = new HRProductTrainingLoginPage(getPage());
		hrProductTrainingDashboardPage = new HRProductTrainingDashboardPage(getPage());
		trainingAssistLoginPage = new TrainingAssistLoginPage(getPage());
		trainingAssistDashboardPage = new TrainingAssistDashboardPage(getPage());
	}

	public void initUtils() {
		log = LoggerFactory.getLogger(Mappings.class);
		xlsReadr = new Xls_Reader();
		dataStorage = new DataStorage();
		customAssert = new CustomAssert();
		jsonUtils = new JsonUtils();
		commonUtils = new CommonUtils();
		apiHelper = new ApiHelper();
		tokenUtils = new TokenUtils();
		fileutils = new FileUtils();
	}

	public void waitforsec(int sec) {
		try {
			log.info("Paused for [" + sec + "] second...");
			Thread.sleep(sec * 1000);
		} catch (Exception e) {
			Thread.currentThread().interrupt();
		}
	}

	public void setTransactionalData(String key, String value) {
		commonUtils.setProperties("transactionalData", Thread.currentThread().getId() + "-" + key, value);
	}

	public String getTransactionalData(String key) {
		String data = commonUtils.getProperties("transactionalData")
				.getProperty(Thread.currentThread().getId() + "-" + key);
		log.info("Data read is : " + data);
		ExtentCucumberAdapter.addTestStepLog("Data read is : " + data);
		return data;
	}

	public String getPageSelectors(String selectorKey) {
		return commonUtils.getProperties("pageSelectors").getProperty(selectorKey);
	}

	public String getEnvConfig(String selectorKey) {
		String env = System.getProperty("env", "PreProd");
		log.info("Loading properties file:[" + env + "_envConfig.properties]");
		return commonUtils.getProperties(env + "_envConfig").getProperty(selectorKey);
	}
}
