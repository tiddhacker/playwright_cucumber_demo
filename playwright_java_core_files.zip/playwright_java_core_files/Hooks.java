package hook;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.automation.common.Mappings;
import com.automation.pages.BasePage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks extends Mappings {

	private Logger log= LoggerFactory.getLogger(Hooks.class);
	
	public Hooks() {
		super();
	}

	@Before("@UI")
	public void setup() {
		initBrowser();
		initUtils();
		initUIClass();
	}

	@Before("@API")
	public void api_setup() {
		initUtils();
	}

	@After("@UI")
	public void tearDown(Scenario scenario) {
		if (scenario.isFailed()) {
			log.error("******************* Scenario Failed *******************");
			if (getPage() != null) {
				basepage.captureScreenshot();
			}
		} else {
			log.info("******************* Scenario Passed ! Executing close browser *******************");
		}

		try {
			if (getPage() != null) {
				getPage().close();
			}
			if (getBrowserContext() != null) {
				getBrowserContext().close();
			}
			if (getBrowser() != null) {
				getBrowser().close();
			}
			if (getPlaywright() != null) {
				getPlaywright().close();
			}
		} catch (Exception e) {
			log.error("Error during browser teardown: " + e.getMessage(), e);
		}
	}


	@After("@API")
	public void disposeAPI(Scenario scenario){
		if (scenario.isFailed()) {
			log.error("*******************" + "Scenario Failed" + "*******************");
		} else if (scenario.isFailed()==false) {
			log.info("*******************" + "Scenario Passed ! Disposing API Context" + "*******************");
		}
		apiHelper.disposeAPIContext();
	}
	
}
